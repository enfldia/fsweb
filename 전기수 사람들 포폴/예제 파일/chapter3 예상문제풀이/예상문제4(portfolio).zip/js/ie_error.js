$(function(){
	var $features=$(".subject .feature:nth-child(3n+0)");
	// $features.css({"margin-right":"0px"});
	$features.addClass("edge");

	var $title=$(".hero .caption p");
	$title.css({"background-color":"#fff", "opacity":"0.6"});
});